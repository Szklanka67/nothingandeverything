//
//  FlippedClipView.h
//  Discord Lite
//
//  Created by Collin Mistr on 10/28/21.
//  Copyright (c) 2021 dosdude1. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FlippedClipView : NSClipView

@end
