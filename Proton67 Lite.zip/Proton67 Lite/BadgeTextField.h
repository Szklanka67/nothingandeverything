//
//  BadgeTextField.h
//  Discord Lite
//
//  Created by Collin Mistr on 11/5/21.
//  Copyright (c) 2021 dosdude1. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BadgeTextField : NSTextField

@end
