//
//  AsyncHTTPGetRequest.h
//  Discord Lite
//
//  Created by Collin Mistr on 10/26/21.
//  Copyright (c) 2021 dosdude1. All rights reserved.
//

#import "AsyncHTTPRequest.h"

@interface AsyncHTTPGetRequest : AsyncHTTPRequest

-(id)init;
-(void)start;

@end
